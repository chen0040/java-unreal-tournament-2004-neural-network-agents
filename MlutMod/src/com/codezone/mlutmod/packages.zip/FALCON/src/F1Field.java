


public class F1Field
{
	protected double mChoiceParameter;
	protected double mLearningRate;
	protected double mContributionParameter;
	protected double mBaselineVigilenceParameter;
	protected double mVigilence;
	protected double mActivityVector[];
	
	public F1Field(double choiceParameter, double learningRate, double contributionParameter, double baselineVigilenceParameter, int activityVectorSize)
	{
		mChoiceParameter=choiceParameter;
		mLearningRate=learningRate;
		mContributionParameter=contributionParameter;
		mBaselineVigilenceParameter=baselineVigilenceParameter;
		mVigilence=baselineVigilenceParameter;
		mActivityVector=new double[activityVectorSize];
		for(int i=0; i != activityVectorSize; ++i)
		{
			mActivityVector[i]=1;
		}
	}

	public double getChoiceParameter()
	{ 
		return mChoiceParameter; 
	}
	public double getLearningRate()
	{ 
		return mLearningRate; 
	}
	public double getContributionParameter() 
	{ 
		return mContributionParameter; 
	}
	public double getBaselineVigilenceParameter()
	{ 
		return mBaselineVigilenceParameter; 
	}
	public double getVigilence()
	{ 
		return mVigilence; 
	}

	public void setChoiceParameter(double param) 
	{ 
		mChoiceParameter=param; 
	}
	public void setLearningRate(double rate)
	{ 
		mLearningRate=rate; 
	}
	public void setBaselineVigilenceParameter(double param) 
	{ 
		mBaselineVigilenceParameter=param; 
	}
	public void setVigilence(double val) 
	{ 
		mVigilence=val; 
	}
	public void setContributionParameter(double param) 
	{ 
		mContributionParameter=param; 
	}

	public int size() 
	{ 
		return mActivityVector.length; 
	}
	public double get(int index) 
	{ 
		return mActivityVector[index]; 
	}
	public void set(int index, double val) 
	{ 
		mActivityVector[index]=val; 
	}
}