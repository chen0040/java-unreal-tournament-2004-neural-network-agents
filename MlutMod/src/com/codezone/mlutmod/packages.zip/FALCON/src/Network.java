


public class Network
{
	protected F1Field mF1Fields[];
	protected CategoryField mCategoryField;
	protected int mMotorFieldSize;
	protected int mSensoryFieldSize;
	
	public static final int REWARD=0;
	public static final int COMPLEMENTARY_REWARD=1;

	public Network(int sensoryFieldSize, int motorFieldSize)
	{
		mF1Fields=new F1Field[3];
		mSensoryFieldSize=sensoryFieldSize;
		mMotorFieldSize=motorFieldSize;
		mCategoryField=new CategoryField(sensoryFieldSize, motorFieldSize);
		
		mF1Fields[CategoryField.SENSORY_FIELD]=new F1Field(0.1, 1.0, 0.5, 0.2, sensoryFieldSize);
		mF1Fields[CategoryField.MOTOR_FIELD]=new F1Field(0.1, 1.0, 0.5, 0.2, motorFieldSize);
		mF1Fields[CategoryField.FEEDBACK_FIELD]=new F1Field(0.1, 1.0, 0, 0.5, 2);
	}

	protected double computeChoiceFunction(int index)
	{
		CategoryNode node=mCategoryField.getNode(index);

		//T is the choice function for the (index) th node in the category field
		double T=0; 

		F1Field field=null;
		
		double t1=0;
		double t2=0;
		double weight=0;
		for(int type=0; type != 3; ++type)
		{
			field=mF1Fields[type];
			int count=field.size();
			t1=0;
			t2=0;
			for(int i=0; i != count; ++i)
			{
				weight=node.getWeight(type, i);
				t1 += Math.min(field.get(i), weight); //fuzzy AND operator | p ^ q | = min(p, q);
				t2 += weight; 
			}

			T += (field.getContributionParameter() * t1 / (field.getChoiceParameter() + t2));
		}
		return T;
	}
	
	protected double computeMatchFunction(int type, int index)
	{
		CategoryNode node=mCategoryField.getNode(index);
		F1Field field=mF1Fields[type];

		double m1=0;
		double m2=0;
		int count=field.size();
		for(int i=0; i<count; ++i)
		{
			m1 += Math.min(field.get(i), node.getWeight(type, i));
			m2 += field.get(i);
		}

		return	m1 / m2;
	}

	public int getMotorFieldSize() 
	{ 
		return mMotorFieldSize; 
	}
	
	public int getSensoryFieldSize() 
	{ 
		return mSensoryFieldSize; 
	}
	
	public boolean loadConfig(String filename)
	{
		return false;
	}
	
	public int getCategoryNodeCount() 
	{ 
		return mCategoryField.size(); 
	}


	protected void setInputs(int type, double[] inputs)
	{
		F1Field field=mF1Fields[type];
		int count=field.size();
		
		for(int i=0; i != count; ++i)
		{
			field.set(i, inputs[i]);
		}
	}
	
	protected void _activate_code(double[] states, double[] action_preferences, double[] rewards)
	{
		setInputs(CategoryField.SENSORY_FIELD, states);
		setInputs(CategoryField.MOTOR_FIELD, action_preferences);
		setInputs(CategoryField.FEEDBACK_FIELD, rewards);

		int categoryFieldSize=mCategoryField.size();

		int J=0;
		double Tmax=0;
		double T=0;
		for(int j=0; j != categoryFieldSize; ++j)
		{
			T=computeChoiceFunction(j); //code activation: the choice function of each node in the category field is computed for their degree of activation

			//code competition: winner node is J which has the highest choice function value
			if(Tmax < T)
			{
				J=j;
				Tmax=T;
			}
		}

		CategoryNode winnerNode=mCategoryField.getNode(J);

		//action selection: the chosen category node performs a readout of its weight vector 
		F1Field field=mF1Fields[CategoryField.MOTOR_FIELD];
		int count=field.size();
		for(int i=0; i != count; ++i)
		{
			action_preferences[i]=Math.min(field.get(i), winnerNode.getWeight(CategoryField.MOTOR_FIELD, i));
		}

		field=mF1Fields[CategoryField.FEEDBACK_FIELD];
		count=field.size();
		for(int i=0; i != count; ++i)
		{
			rewards[i]=Math.min(field.get(i), winnerNode.getWeight(CategoryField.FEEDBACK_FIELD, i));
		}
	}
	
	protected void _learn(double[] states, double[] action_preferences, double[] rewards)
	{
		setInputs(CategoryField.SENSORY_FIELD, states);
		setInputs(CategoryField.MOTOR_FIELD, action_preferences);
		setInputs(CategoryField.FEEDBACK_FIELD, rewards);

		int categoryFieldSize=mCategoryField.size();

		double[] Ts=new double[categoryFieldSize];
		double T=0;
		for(int j=0; j != categoryFieldSize; ++j)
		{
			T=computeChoiceFunction(j);
			Ts[j]=T;
		}

		F1Field sensoryField=mF1Fields[CategoryField.SENSORY_FIELD];
		F1Field motorField=mF1Fields[CategoryField.MOTOR_FIELD];
		F1Field feedbackField=mF1Fields[CategoryField.FEEDBACK_FIELD];

		sensoryField.setVigilence(sensoryField.getBaselineVigilenceParameter());

		int J=0;
		boolean reset=true;
		boolean perfectMismatch=false;
		double Tmax=0;
		double match[]=new double[3];
		for(int i=0; i !=3; ++i)
		{
			match[i]=0;
		}
		
		while(reset==true && perfectMismatch==false)
		{
			reset=false;

			//get the category node J which has the highest choice function value
			Tmax=0;
			J=categoryFieldSize+1;
			for(int j=0; j != categoryFieldSize; ++j)
			{
				if(Tmax < Ts[j])
				{
					J=j;
					Tmax=Ts[j];
				}
			}

			match[CategoryField.SENSORY_FIELD]=computeMatchFunction(CategoryField.SENSORY_FIELD, J);
			match[CategoryField.MOTOR_FIELD]=computeMatchFunction(CategoryField.MOTOR_FIELD, J);
			match[CategoryField.FEEDBACK_FIELD]=computeMatchFunction(CategoryField.FEEDBACK_FIELD, J);

			//if any of the vigilance constraints is violated, mismatch reset occurs in which the value of the choice function Ts[J] is set to -1 for the during of input representation
			//and the search process repeats to select another node J until resonance occurs. 
			if(match[CategoryField.SENSORY_FIELD] < sensoryField.getVigilence() ||
				match[CategoryField.MOTOR_FIELD] < motorField.getVigilence() ||
				match[CategoryField.FEEDBACK_FIELD] < feedbackField.getVigilence())
			{
				if (match[CategoryField.SENSORY_FIELD] == 1)
				{
					perfectMismatch=true;
				}
				else
				{
					Ts[J] = -1;
					reset=true;
					if(sensoryField.getVigilence() < match[CategoryField.SENSORY_FIELD])
					{
						sensoryField.setVigilence(Math.min(match[CategoryField.SENSORY_FIELD]+0.001, 1));
					}
				}
			}
		}
		
		CategoryNode nodeJ=mCategoryField.getNode(J);
		if(perfectMismatch) //if perfect mismatch, do overwrite
		{
			int count=0;
			for(int type=0; type != 3; ++type)
			{
				count=mF1Fields[type].size();
				for(int i=0; i != count; ++i)
				{
					nodeJ.setWeight(type, i, mF1Fields[type].get(i));
				}
			}
		}
		else //other wise, learn		
		{
			double newWeight=0;
			double oldWeight=0;
			double learningRate=0;
			int count=0;

			F1Field field=null;
			for(int type=0; type != 3; ++type)
			{
				field=mF1Fields[type];
				learningRate=field.getLearningRate();
				count=field.size();
				for(int i=0; i != count; ++i)
				{
					oldWeight=nodeJ.getWeight(type, i);
					newWeight=(1-learningRate) * oldWeight + learningRate * Math.min(field.get(i), oldWeight);
					nodeJ.setWeight(type, i, newWeight);
				}
			}
			
			//if J node is uncommitted, then after learning, it becomes committed and a new uncommitted node is inserted into the category field
			if(nodeJ.isCommitted()==false)
			{
				nodeJ.commit();
				mCategoryField.createNode();
			}
		}
	}
	
	public double predictQValue(double[] states, int action_index)
	{
		//initialize the reward fields to (1, 1)
		double rewards[]=new double[2];
		for(int i=0; i !=2; ++i)
		{
			rewards[i]=1;
		}

		//initialize the action vector to all 0 except for the element at action_index which should be set to 1
		double action_preferences[]=new double[mMotorFieldSize];
		for(int i=0; i != mMotorFieldSize; ++i)
		{
			action_preferences[i]=0;
		}
		action_preferences[action_index]=1;

		this._activate_code(states, action_preferences, rewards);

		return rewards[REWARD] / (rewards[REWARD]+rewards[COMPLEMENTARY_REWARD]);
	}
}