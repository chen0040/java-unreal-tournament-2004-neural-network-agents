


public abstract class TDFALCON extends Network
{
	public static final int QRULE_THRESHOLD=0;
	public static final int QRULE_BOUNDED=1;
	
	protected double mActionPreferences[];
	protected double mCurrStates[];
	protected double mCurrQValues[];
	int mCurrAction;
	protected double mRewards[];

	protected int mQRule; //rule for bounding the value of QValue within the range of rewards, i.e., [0, 1]
	protected double mDiscount; //the discount in the Q-learning rule
	protected double mLearningRate; //the learning rate in the Q-learning rule;
	
	public TDFALCON(int sensoryFieldSize, int motorFieldSize)
	{
		super(sensoryFieldSize, motorFieldSize);
		mCurrStates=new double[sensoryFieldSize];
		for(int i=0; i != sensoryFieldSize; ++i)
		{
			mCurrStates[sensoryFieldSize]=1;
		}
		
		mActionPreferences=new double[motorFieldSize];
		for(int i=0; i != motorFieldSize; ++i)
		{
			mActionPreferences[i]=1;
		}
		
		mCurrQValues=new double[motorFieldSize];
		for(int i=0; i != motorFieldSize; ++i)
		{
			mCurrQValues[i]=1;
		}
		
		mRewards=new double[2];
		for(int i=0; i != 2; ++i)
		{
			mRewards[i]=0;
		}
		
		mDiscount=0.1;
		
		mQRule=QRULE_BOUNDED;
	}

	public abstract int predict(double[] states);
	public abstract void learn(double[] next_states, double immediate_reward, boolean penalty);

	public void setQRule(int rule) 
	{ 
		mQRule=rule; 
	}
	
	public void setDiscount(double discount) 
	{ 
		mDiscount=discount; 
	}
	
	public void setLearningRate(double rate) 
	{ 
		mLearningRate=rate; 
	}
	
	protected double constrainQValue(double value, int rule)
	{
		double QValue=value;
		if(rule==QRULE_THRESHOLD)
		{
			if(QValue > 1) 
			{
				QValue=1;
			}
			else if(QValue < 0)
			{
				QValue=0;
			}
		}

		return QValue;
	}
}