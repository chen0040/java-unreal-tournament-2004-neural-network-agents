


import java.util.*;

public class CategoryField
{
	public final static int SENSORY_FIELD=0;
	public final static int MOTOR_FIELD=1;
	public final static int FEEDBACK_FIELD=2;
	protected int mSensoryFieldSize;
	protected int mMotorFieldSize;
	protected ArrayList<CategoryNode> mNodes=new ArrayList<CategoryNode>();

	public CategoryField(int sensoryFieldSize,  int motorFieldSize)
	{
		mSensoryFieldSize=sensoryFieldSize;
		mMotorFieldSize=motorFieldSize;
		
		mNodes.add(new CategoryNode(sensoryFieldSize, motorFieldSize));
	}
	
	public int size()	
	{ 
		return mNodes.size(); 
	}
	
	public void createNode()
	{
		CategoryNode node=new CategoryNode(mSensoryFieldSize, mMotorFieldSize);
		mNodes.add(node);
	}
	
	CategoryNode getNode(int i) 
	{ 
		return mNodes.get(i); 
	}
}