


public class QFALCON extends TDFALCON
{
	public QFALCON(int sensoryFieldSize, int motorFieldSize)
	{
		super(sensoryFieldSize, motorFieldSize);
	}

	public int predict(double[] states)
	{
		for(int i=0; i != mSensoryFieldSize; ++i)
		{
			mCurrStates[i]=states[i];
		}

		//Step A: value prediction
		for(int j=0; j != mMotorFieldSize; ++j)
		{
			mCurrQValues[j]=predictQValue(mCurrStates, j);
		}

		//Step B: action selection
		mCurrAction=ASM.epsilon_greedy(mCurrQValues, 0.1);

		return mCurrAction;
	}
	
	public void learn(double[] next_states, double immediate_reward, boolean penalty)
	{
		//compute the maximum estimated QValue of the next states
		double Qmax_nextState=0;
		for(int j=0; j != mMotorFieldSize; ++j)
		{
			double Qj=predictQValue(next_states, j);
			Qj=constrainQValue(Qj, mQRule);
			if(Qj > Qmax_nextState)
			{
				Qmax_nextState=Qj;
			}
		}

		//get QValue of current state-action pair
		double QValue_currState=constrainQValue(mCurrQValues[mCurrAction], mQRule);

		//compuete TD error
		double TDErr=immediate_reward + mDiscount * Qmax_nextState - QValue_currState;

		//compute the delta QValue
		double dQValue=0;
		if(mQRule==QRULE_BOUNDED)
		{
			dQValue=mLearningRate * TDErr * ( 1 - QValue_currState);
		}
		else
		{
			dQValue=mLearningRate * TDErr;
		}

		//update QValue of the current state-action pair
		QValue_currState+=dQValue;

		//a_j=1 if a_j corresponds to the current action, and a_j=0 for otherwise
		for(int j=0; j != mMotorFieldSize; ++j)
		{
			mActionPreferences[j]=0;
		}
		mActionPreferences[mCurrAction]=1;

		//set reward to the updated QValue 
		mRewards[REWARD]=QValue_currState;
		mRewards[COMPLEMENTARY_REWARD]=1-mRewards[REWARD];

		_learn(mCurrStates, mActionPreferences, mRewards);
	}
}