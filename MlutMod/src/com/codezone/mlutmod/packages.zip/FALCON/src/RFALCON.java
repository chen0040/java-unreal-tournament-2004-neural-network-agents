


public class RFALCON extends Network
{
	RFALCON(int sensoryFieldSize, int motorFieldSize)
	{
		super(sensoryFieldSize, motorFieldSize);
		
		mCurrStates=new double[sensoryFieldSize];
		for(int i=0; i != sensoryFieldSize; ++i)
		{
			mCurrStates[i]=1;
		}
		
		mActionPreferences=new double[motorFieldSize];
		for(int i=0; i != motorFieldSize; ++i)
		{
			mActionPreferences[i]=1;
		}
		
		mRewards=new double[2];
		for(int i=0; i != 2; ++i)
		{
			mRewards[i]=0;
		}
	}

	public int predict(double[] states)
	{
		for(int i=0; i != mSensoryFieldSize; ++i)
		{
			mCurrStates[i]=states[i];
		}

		//by default, prior to prediction, action inputs are all set to 1
		for(int i=0; i != mMotorFieldSize; ++i)
		{
			mActionPreferences[i]=1;
		}

		//by default, the reward inputs is {r, r_bar} where r=1 and r_bar=1-r
		mRewards[Network.REWARD]=1;
		mRewards[Network.COMPLEMENTARY_REWARD]=0;

		//code activation;
		_activate_code(mCurrStates, mActionPreferences, mRewards);

		//code competition;
		mCurrAction=ASM.winner_take_all(mActionPreferences);

		return mCurrAction;
	}
	
	public void learn(double reward, boolean penalty)
	{
		mRewards[Network.REWARD]=reward;
		mRewards[Network.COMPLEMENTARY_REWARD]=1-reward;

		if(penalty)
		{
			mRewards[REWARD]=1-mRewards[REWARD];
			mRewards[COMPLEMENTARY_REWARD]=1-mRewards[COMPLEMENTARY_REWARD];
			for(int j=0; j != mMotorFieldSize; ++j)
			{
				mActionPreferences[j]=1-mActionPreferences[j];
			}
		}

		_learn(mCurrStates, mActionPreferences, mRewards);
	}

	private double mActionPreferences[];
	private double mCurrStates[];
	private int mCurrAction;
	private double mRewards[];
}
