

public class CategoryNode
{
	protected double mWeights[][];
	protected boolean mCommitted;

	public CategoryNode(int sensoryFieldSize, int motorFieldSize)
	{
		mWeights=new double[3][];
		
		//initialize to uncommitted node which contains all 1s
		mWeights[CategoryField.SENSORY_FIELD]=new double[sensoryFieldSize];
		for(int i=0; i != sensoryFieldSize; ++i)
		{
			mWeights[CategoryField.SENSORY_FIELD][i]=1;
		}
		mWeights[CategoryField.MOTOR_FIELD]=new double[motorFieldSize];
		for(int i=0; i != motorFieldSize; ++i)
		{
			mWeights[CategoryField.MOTOR_FIELD][i]=1;
		}
		mWeights[CategoryField.FEEDBACK_FIELD]=new double[2];
		for(int i=0; i != 2; ++i)
		{
			mWeights[CategoryField.FEEDBACK_FIELD][i]=1;
		}
		
		mCommitted=false;
	}


	public boolean isCommitted() 
	{ 
		return mCommitted; 
	}
	
	public void commit() 
	{ 
		mCommitted=true; 
	}


	public double getWeight(int type, int index)
	{ 
		return mWeights[type][index]; 
	}
	
	public void setWeight(int type, int index, double weight) 
	{ 
		mWeights[type][index]=weight; 
	}
}