


class ASM
{
	private ASM() { }

	public static int epsilon_greedy(double[] QValues, double epsilon)
	{
		int action_count=QValues.length;
		int J=action_count+1;

		double Qmax=0;
		for(int j=0; j != action_count; ++j)
		{
			if(Qmax < QValues[j])
			{
				Qmax=QValues[j];
				J=j;
			}
		}

		double accumulated_fitness[]=new double[action_count];
		double sum=0, probability;
		double epsi_pie=epsilon / action_count; 
		
		for(int j=0; j != action_count; ++j)
		{
			if(j == J)
			{
				probability=1 - epsilon + epsi_pie;
			}
			else
			{
				probability=epsi_pie;
			}
			
			sum+=probability;
			accumulated_fitness[j]=sum;
		}

		double r=Math.random();
		for(int j=0; j != action_count; ++j)
		{
			if(r < accumulated_fitness[j])
			{
				return j;	
			}
		}

		return J;
	}
	
	public static int soft_max(double[] action_preferences, double[] QValues, double temperature)
	{
		int action_count=action_preferences.length;
		int J=action_count+1;

		double Amax=0;
		for(int j=0; j != action_count; ++j)
		{
			if(Amax < action_preferences[j])
			{
				Amax=action_preferences[j];
				J=j;
			}
		}

		double accumulated_fitness[]=new double[action_count];
		//double pie_vector[]=new double[action_count];
		double sum=0;	
		for(int j=0; j != action_count; ++j)
		{
			sum+=Math.exp(QValues[j] / temperature);
			accumulated_fitness[j]=sum;
		}

		for(int j=0; j != action_count; ++j)
		{
			accumulated_fitness[j] /= sum;
		}

		double r=Math.random();
		for(int j=0; j != action_count; ++j)
		{
			if(r < accumulated_fitness[j])
			{
				return j;	
			}
		}

		return J;
	}
	
	public static int winner_take_all(double[] action_preferences)
	{
		//J will be the action that has the highest preferences
		int action_count=action_preferences.length;
		int J=action_count+1;
		double Amax=0;
		for(int j=0; j != action_count; ++j)
		{
			if(Amax < action_preferences[j])
			{
				Amax=action_preferences[j];
				J=j;
			}
		}
		return J;
	}
}